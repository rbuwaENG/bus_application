class GoogleMapApi {
  String _url = 'AIzaSyAxRtxZO46N5V9fczlJXyB84_qtfxjyMfA';

  String get url => _url;
}
